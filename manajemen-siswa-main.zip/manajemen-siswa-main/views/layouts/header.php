<?php
$currentPage = basename($_SERVER['PHP_SELF']);
$isDaftar = in_array($currentPage, ['index.php', 'student.php', 'edit.php']);
$isTambah = $currentPage === 'create.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Siswa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <a href="index.php" class="navbar-brand">
        <span class="brand-title">SMK MIFTAHUL KHOIR</span>
        <span class="brand-sub">Manajemen Siswa</span>
    </a>

    <div class="navbar-menu">
        <a href="index.php" class="<?= $isDaftar ? 'active' : '' ?>">Daftar Siswa</a>
        <a href="create.php" class="<?= $isTambah ? 'active' : '' ?>">+ Tambah Siswa</a>
        <a href="logout.php" class="logout" onclick="return confirm('Yakin ingin keluar?')">
            Logout (<?= htmlspecialchars($_SESSION['username'] ?? '') ?>)
        </a>
    </div>
</nav>