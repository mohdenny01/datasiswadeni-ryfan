<footer class="footer">
    <p class="footer-title">SMK MIFTAHUL KHOIR</p>
    <p class="footer-text">
        &copy; <?= date('Y') ?> Manajemen Siswa. Semua hak dilindungi.
    </p>
</footer>
</body>
</html>