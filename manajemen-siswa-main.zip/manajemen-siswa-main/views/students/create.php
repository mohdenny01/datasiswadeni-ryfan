
<?php require __DIR__ . '/../layouts/header.php'; ?>

<style>
/* AREA FORM */
.create-container {
    max-width: 1000px;
    margin: 30px auto;
    padding: 20px;
}

/* JUDUL */
.create-heading {
    margin-bottom: 25px;
}

.create-heading h1 {
    color: #24469d;
    font-size: 27px;
    margin-bottom: 8px;
}

.create-heading p {
    color: #8792a5;
    font-size: 14px;
}

/* CARD FORM */
.form-card {
    background: white;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 4px 20px #0000000c;
    border: 1px solid #edf0f7;
}

.form-title {
    color: #24469d;
    font-size: 18px;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid #edf0f7;
}

/* GRID INPUT */
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    color: #34446b;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 9px;
}

.form-group input[type="text"],
.form-group input[type="date"] {
    width: 100%;
    padding: 13px 15px;
    border: 1px solid #dce3ef;
    border-radius: 9px;
    outline: none;
    font-size: 14px;
    color: #34446b;
    background: #fbfcff;
    transition: .3s;
}

.form-group input:focus {
    border-color: #3269e8;
    background: white;
    box-shadow: 0 0 0 3px #3269e820;
}

/* JENIS KELAMIN */
.gender-options {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.gender-option {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 18px;
    border: 1px solid #dce3ef;
    border-radius: 9px;
    cursor: pointer;
    color: #34446b;
    font-size: 14px;
    background: #fbfcff;
}

.gender-option input {
    accent-color: #3269e8;
}

/* TOMBOL */
.form-actions {
    display: flex;
    gap: 12px;
    margin-top: 15px;
    padding-top: 22px;
    border-top: 1px solid #edf0f7;
}

.btn-simpan {
    background: linear-gradient(135deg, #24469d, #3269e8);
    color: white;
    border: none;
    padding: 13px 25px;
    border-radius: 9px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    transition: .3s;
}

.btn-simpan:hover {
    background: #214fc1;
    transform: translateY(-2px);
}

.btn-batal {
    background: #eef1f7;
    color: #58657b;
    padding: 13px 25px;
    border-radius: 9px;
    text-decoration: none;
    font-size: 14px;
    font-weight: bold;
    transition: .3s;
}

.btn-batal:hover {
    background: #dfe5ef;
}

/* KETERANGAN */
.form-note {
    background: #eef4ff;
    color: #4265a9;
    padding: 13px;
    border-radius: 8px;
    font-size: 13px;
    margin-bottom: 23px;
}

/* RESPONSIVE */
@media(max-width: 650px) {
    .create-container {
        padding: 12px;
        margin: 15px auto;
    }

    .form-card {
        padding: 20px;
    }

    .form-grid {
        grid-template-columns: 1fr;
        gap: 0;
    }

    .create-heading h1 {
        font-size: 23px;
    }

    .form-actions {
        flex-wrap: wrap;
    }
}
</style>

<div class="create-container">

    <!-- JUDUL -->
    <div class="create-heading">
        <h1>Tambah Siswa</h1>
        <p>Dashboard / Data Siswa / Tambah Siswa</p>
    </div>

    <!-- FORM CARD -->
    <div class="form-card">

        <h3 class="form-title">
            👨‍🎓 Formulir Data Siswa
        </h3>

        <div class="form-note">
            ℹ️ Silakan lengkapi seluruh data siswa dengan benar.
            Kolom bertanda wajib harus diisi.
        </div>

        <form action="create.php" method="POST">

            <div class="form-grid">

                <!-- NIS -->
                <div class="form-group">
                    <label>NIS *</label>

                    <input
                        type="text"
                        name="nis"
                        placeholder="Masukkan NIS siswa"
                        required
                    >
                </div>

                <!-- NAMA -->
                <div class="form-group">
                    <label>Nama Lengkap *</label>

                    <input
                        type="text"
                        name="name"
                        placeholder="Masukkan nama lengkap"
                        required
                    >
                </div>

                <!-- TEMPAT LAHIR -->
                <div class="form-group">
                    <label>Tempat Lahir</label>

                    <input
                        type="text"
                        name="birth_place"
                        placeholder="Contoh: Surabaya"
                    >
                </div>

                <!-- TANGGAL LAHIR -->
                <div class="form-group">
                    <label>Tanggal Lahir</label>

                    <input
                        type="date"
                        name="birth_date"
                    >
                </div>

                <!-- KELAS -->
                <div class="form-group">
                    <label>Kelas *</label>

                    <input
                        type="text"
                        name="class_name"
                        placeholder="Contoh: IX"
                        required
                    >
                </div>

                <!-- JURUSAN -->
                <div class="form-group">
                    <label>Jurusan *</label>

                    <input
                        type="text"
                        name="major"
                        placeholder="Contoh: TKJ"
                        required
                    >
                </div>

            </div>

            <!-- JENIS KELAMIN -->
            <div class="form-group">

                <label>Jenis Kelamin *</label>

                <div class="gender-options">

                    <label class="gender-option">
                        <input
                            type="radio"
                            name="gender"
                            value="L"
                            required
                        >
                        👨 Laki-laki
                    </label>

                    <label class="gender-option">
                        <input
                            type="radio"
                            name="gender"
                            value="P"
                        >
                        👩 Perempuan
                    </label>

                </div>

            </div>

            <!-- TOMBOL -->
            <div class="form-actions">

                <button type="submit" class="btn-simpan">
                    ✓ Simpan Data
                </button>

                <a href="index.php" class="btn-batal">
                    ← Batal
                </a>

            </div>

        </form>

    </div>

</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
