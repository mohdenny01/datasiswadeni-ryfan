<?php require __DIR__ . '/../layouts/header.php'; ?>

<h1>Detail Siswa</h1>
<div class="container">

    <?php if (!empty($success)): ?>
        <div style="background:#d4edda; color:#155724; border:1px solid #c3e6cb; padding:10px; margin-bottom:15px;">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <p>
        NIS:
        <?= $student['nis'] ?>
    </p>

    <p>
        Nama:
        <?= $student['name'] ?>
    </p>

    <p>
        Kelas:
        <?= $student['class_name'] ?>
    </p>

    <p>
        Jurusan:
        <?= $student['major'] ?>
    </p>

    <a href="index.php">
        ← Kembali
    </a>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>