
<?php
// Data siswa dari controller/database
$totalSiswa = count($students);

// Menghitung jumlah siswa berdasarkan kelas
$kelasData = [];

foreach ($students as $student) {
    $kelas = $student['class_name'];
    if (!isset($kelasData[$kelas])) {
        $kelasData[$kelas] = 0;
    }
    $kelasData[$kelas]++;
}

$totalKelas = count($kelasData);

// Data grafik
$labelsKelas = array_keys($kelasData);
$jumlahPerKelas = array_values($kelasData);

// Data siswa terbaru
$siswaTerbaru = array_slice(array_reverse($students), 0, 5);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Admin - SMK Miftahul Khair</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Arial, sans-serif;
}

body {
    background: #f4f6fc;
    color: #263451;
}

/* SIDEBAR */
.sidebar {
    width: 245px;
    height: 100vh;
    background: linear-gradient(180deg, #244bc0, #3978ed);
    position: fixed;
    left: 0;
    top: 0;
    padding: 25px 15px;
    color: white;
}

.logo {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px;
    margin-bottom: 35px;
}

.logo-icon {
    background: #ffffff30;
    padding: 12px;
    border-radius: 12px;
    font-size: 25px;
}

.logo h2 {
    font-size: 17px;
}

.logo p {
    font-size: 11px;
    opacity: .8;
    margin-top: 4px;
}

.menu-title {
    font-size: 11px;
    opacity: .65;
    margin: 15px 12px;
    letter-spacing: 1px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #e7edff;
    text-decoration: none;
    padding: 13px 14px;
    margin-bottom: 7px;
    border-radius: 9px;
    font-size: 14px;
    transition: .3s;
}

.menu a:hover,
.menu a.active {
    background: white;
    color: #2853c4;
    font-weight: bold;
}

.menu-icon {
    font-size: 17px;
    width: 22px;
    text-align: center;
}

/* MAIN */
.main {
    margin-left: 245px;
    padding: 25px 30px;
}

/* TOPBAR */
.topbar {
    background: white;
    padding: 16px 22px;
    border-radius: 13px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 3px 15px #00000008;
    margin-bottom: 28px;
}

.topbar h2 {
    font-size: 21px;
    color: #243b76;
}

.admin {
    display: flex;
    align-items: center;
    gap: 12px;
}

.avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: #e7efff;
    color: #2853c4;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
}

.admin span {
    font-size: 13px;
    font-weight: bold;
}

/* JUDUL */
.welcome {
    margin-bottom: 23px;
}

.welcome h2 {
    font-size: 23px;
    color: #253e7e;
    margin-bottom: 7px;
}

.welcome p {
    color: #8993a7;
    font-size: 13px;
}

/* STATISTIK */
.stats {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin-bottom: 23px;
}

.stat-card {
    background: white;
    padding: 23px;
    border-radius: 13px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 3px 15px #00000008;
}

.stat-card p {
    color: #8b95a8;
    font-size: 13px;
}

.stat-card h1 {
    font-size: 29px;
    color: #34416b;
    margin-top: 8px;
}

.stat-icon {
    width: 55px;
    height: 55px;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 25px;
}

.blue {
    background: #e7efff;
}

.green {
    background: #e2f8eb;
}

/* GRAFIK */
.charts {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 23px;
}

.chart-card {
    background: white;
    padding: 22px;
    border-radius: 13px;
    box-shadow: 0 3px 15px #00000008;
}

.chart-card h3 {
    font-size: 15px;
    color: #36446c;
    margin-bottom: 20px;
}

.chart-container {
    height: 240px;
    position: relative;
}

/* AKTIVITAS */
.activity {
    background: white;
    padding: 22px;
    border-radius: 13px;
    box-shadow: 0 3px 15px #00000008;
}

.activity-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
}

.activity h3 {
    font-size: 16px;
    color: #36446c;
}

.activity table {
    width: 100%;
    border-collapse: collapse;
}

.activity th {
    text-align: left;
    background: #f5f7fc;
    padding: 13px;
    color: #8290a5;
    font-size: 12px;
}

.activity td {
    padding: 13px;
    border-bottom: 1px solid #edf0f5;
    font-size: 13px;
}

.nama-siswa {
    font-weight: bold;
    color: #34416b;
}

.jurusan {
    color: #2864d9;
    background: #edf3ff;
    padding: 5px 10px;
    border-radius: 15px;
    font-size: 11px;
}

.btn-tambah {
    background: #3269e8;
    color: white;
    padding: 11px 17px;
    text-decoration: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: bold;
}

.btn-tambah:hover {
    background: #214fc1;
}

.btn-detail {
    color: #2864d9;
    text-decoration: none;
    font-weight: bold;
}

.footer {
    text-align: center;
    color: #929caf;
    font-size: 12px;
    padding: 25px 0 10px;
}

/* RESPONSIVE */
@media(max-width: 900px) {
    .sidebar {
        width: 190px;
    }

    .main {
        margin-left: 190px;
        padding: 20px;
    }

    .charts {
        grid-template-columns: 1fr;
    }
}

@media(max-width: 600px) {
    .sidebar {
        width: 65px;
        padding: 15px 8px;
    }

    .logo h2,
    .logo p,
    .menu-title,
    .menu a span:last-child {
        display: none;
    }

    .logo {
        justify-content: center;
        padding: 5px;
    }

    .menu a {
        justify-content: center;
        padding: 13px 5px;
    }

    .main {
        margin-left: 65px;
        padding: 12px;
    }

    .stats {
        grid-template-columns: 1fr;
    }

    .topbar {
        padding: 13px;
    }

    .topbar h2 {
        font-size: 16px;
    }

    .activity {
        overflow-x: auto;
    }

    .activity table {
        min-width: 500px;
    }
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">

    <div class="logo">
        <div class="logo-icon">🎓</div>
        <div>
            <h2>SMK MIFTAHUL KHAIR</h2>
            <p>Manajemen Siswa</p>
        </div>
    </div>

    <div class="menu-title">MENU UTAMA</div>

    <div class="menu">

        <a href="dashboard.php" class="active">
            <span class="menu-icon">▦</span>
            <span>Dashboard</span>
        </a>

        <a href="index.php">
            <span class="menu-icon">👨‍🎓</span>
            <span>Data Siswa</span>
        </a>

        <a href="#kelas">
            <span class="menu-icon">📚</span>
            <span>Kelas</span>
        </a>

        <a href="#jurusan">
            <span class="menu-icon">🎓</span>
            <span>Jurusan</span>
        </a>

        <a href="#laporan">
            <span class="menu-icon">📊</span>
            <span>Laporan</span>
        </a>

    </div>

    <div class="menu-title">AKUN</div>

    <div class="menu">
        <a href="logout.php"
           onclick="return confirm('Yakin ingin logout?')">
            <span class="menu-icon">🚪</span>
            <span>Logout</span>
        </a>
    </div>

</div>

<!-- MAIN CONTENT -->
<div class="main">

    <!-- TOPBAR -->
    <div class="topbar">
        <h2>Statistik</h2>

        <div class="admin">
            <span>🔔</span>
            <div class="avatar">A</div>
            <span>Admin ▾</span>
        </div>
    </div>

    <!-- WELCOME -->
    <div class="welcome">
        <h2>Dashboard Manajemen Siswa</h2>
        <p>Selamat datang di sistem informasi SMK Miftahul Khair.</p>
    </div>

    <!-- TOMBOL -->
    <div style="margin-bottom:22px;">
        <a href="create.php" class="btn-tambah">
            + Tambah Siswa
        </a>
        <a href="index.php"
           class="btn-tambah"
           style="background:#fff;color:#3269e8;border:1px solid #dce5fa;margin-left:7px;">
            Data Siswa
        </a>
    </div>

    <!-- STATISTIK -->
    <div class="stats">

        <div class="stat-card">
            <div>
                <p>Total Seluruh Siswa</p>
                <h1><?= $totalSiswa ?></h1>
                <p>Data siswa terdaftar</p>
            </div>

            <div class="stat-icon blue">👨‍🎓</div>
        </div>

        <div class="stat-card">
            <div>
                <p>Total Kelas</p>
                <h1><?= $totalKelas ?></h1>
                <p>Kelas yang memiliki siswa</p>
            </div>

            <div class="stat-icon green">📚</div>
        </div>

    </div>

    <!-- GRAFIK -->
    <div class="charts">

        <div class="chart-card">
            <h3>Distribusi Siswa Berdasarkan Kelas</h3>

            <div class="chart-container">
                <canvas id="chartKelas"></canvas>
            </div>
        </div>

        <div class="chart-card">
            <h3>Grafik Jumlah Siswa Per Kelas</h3>

            <div class="chart-container">
                <canvas id="chartBatang"></canvas>
            </div>
        </div>

    </div>

    <!-- AKTIVITAS TERBARU -->
    <div class="activity">

        <div class="activity-header">
            <h3>Aktivitas Terbaru - Data Siswa</h3>
        </div>

        <table>

            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>NIS</th>
                    <th>Kelas</th>
                    <th>Jurusan</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>

            <?php if (!empty($siswaTerbaru)): ?>

                <?php foreach ($siswaTerbaru as $index => $student): ?>

                <tr>
                    <td><?= $index + 1 ?></td>

                    <td class="nama-siswa">
                        <?= htmlspecialchars($student['name']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($student['nis']) ?>
                    </td>

                    <td>
                        <?= htmlspecialchars($student['class_name']) ?>
                    </td>

                    <td>
                        <span class="jurusan">
                            <?= htmlspecialchars($student['major']) ?>
                        </span>
                    </td>

                    <td>
                        <a class="btn-detail"
                           href="student.php?id=<?= urlencode($student['id']) ?>">
                            Detail →
                        </a>
                    </td>
                </tr>

                <?php endforeach; ?>

            <?php else: ?>

                <tr>
                    <td colspan="6" style="text-align:center;padding:25px;">
                        Belum ada data siswa.
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

    <!-- FOOTER -->
    <div class="footer">
        © 2026 SMK MIFTAHUL KHAIR. All Rights Reserved.
        <br>
        Sistem Informasi Manajemen Siswa
    </div>

</div>

<!-- SCRIPT GRAFIK -->
<script>

const labelsKelas = <?= json_encode($labelsKelas) ?>;
const jumlahKelas = <?= json_encode($jumlahPerKelas) ?>;

// Grafik Lingkaran
new Chart(document.getElementById('chartKelas'), {

    type: 'doughnut',

    data: {
        labels: labelsKelas,

        datasets: [{
            data: jumlahKelas,
            backgroundColor: [
                '#3269e8',
                '#62c58b',
                '#8b9cf4',
                '#f5b84c',
                '#ed829d',
                '#50b9cf'
            ],
            borderWidth: 3,
            borderColor: '#ffffff'
        }]
    },

    options: {
        responsive: true,
        maintainAspectRatio: false,

        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }

});

// Grafik Batang
new Chart(document.getElementById('chartBatang'), {

    type: 'bar',

    data: {
        labels: labelsKelas,

        datasets: [{
            label: 'Jumlah Siswa',
            data: jumlahKelas,
            backgroundColor: '#4779ed',
            borderRadius: 7,
            barThickness: 25
        }]
    },

    options: {
        responsive: true,
        maintainAspectRatio: false,

        plugins: {
            legend: {
                display: false
            }
        },

        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    precision: 0
                }
            }
        }
    }

});

</script>

</body>
</html>
